#!/usr/bin/env bun
import { orchestrateCommand } from './src/orchestrate.ts';

async function main() {
  const args = process.argv.slice(2);

  if (args.length < 2) {
    console.log('Usage: bun run runner.ts <userId> <command>');
    console.log('Example: bun run runner.ts 91242342 "/pnl"');
    process.exit(1);
  }

  const [userId, command] = args;

  try {
    await orchestrateCommand(userId, command);
  } catch (error) {
    console.error('Runner error:', error);
    process.exit(1);
  }
}

main();