import fs from 'fs';
import { buyWithUSDT, buyByQuantity, sellWithUSDT, sellByQuantity, getPortfolio, formatPortfolio, calculatePnL, formatPnL } from './asterdex-lib/index.js';

interface Command {
  userId: string;
  command: string;
  args: string[];
}

interface CommandResult {
  success: boolean;
  message: string;
  data?: any;
}

// ============ COMMAND EXECUTION FUNCTIONS ============

async function executePortfolio(userId: string): Promise<CommandResult> {
  const result = await getPortfolio(userId);

  if (result.success) {
    const formattedPortfolio = formatPortfolio(result);
    return {
      success: true,
      message: formattedPortfolio,
      data: result.balances
    };
  } else {
    return {
      success: false,
      message: result.message,
      data: result.error
    };
  }
}

async function executeBuyInUSDT(userId: string, symbol: string, usdtAmount: number): Promise<CommandResult> {
  // Validation
  if (usdtAmount < 5) {
    return {
      success: false,
      message: `❌ Minimum order value is $5 USDT. You tried to buy $${usdtAmount}`
    };
  }

  const result = await buyWithUSDT(userId, symbol + 'USDT', usdtAmount);

  return {
    success: result.success,
    message: result.message,
    data: result.success ? {
      orderId: result.orderId,
      executedQty: result.executedQty,
      avgPrice: result.avgPrice
    } : result.error
  };
}

async function executeSellInUSDT(userId: string, symbol: string, usdtAmount: number): Promise<CommandResult> {
  // Validation
  if (usdtAmount < 5) {
    return {
      success: false,
      message: `❌ Minimum order value is $5 USDT. You tried to sell $${usdtAmount} worth`
    };
  }

  const result = await sellWithUSDT(userId, symbol + 'USDT', usdtAmount);

  return {
    success: result.success,
    message: result.message,
    data: result.success ? {
      orderId: result.orderId,
      executedQty: result.executedQty,
      avgPrice: result.avgPrice
    } : result.error
  };
}

async function executeBuy(userId: string, symbol: string, quantity: number): Promise<CommandResult> {
  const result = await buyByQuantity(userId, symbol + 'USDT', quantity);

  return {
    success: result.success,
    message: result.message,
    data: result.success ? {
      orderId: result.orderId,
      executedQty: result.executedQty,
      avgPrice: result.avgPrice,
      cumQuote: result.cumQuote
    } : result.error
  };
}

async function executeSell(userId: string, symbol: string, quantity: number): Promise<CommandResult> {
  const result = await sellByQuantity(userId, symbol + 'USDT', quantity);

  return {
    success: result.success,
    message: result.message,
    data: result.success ? {
      orderId: result.orderId,
      executedQty: result.executedQty,
      avgPrice: result.avgPrice,
      cumQuote: result.cumQuote
    } : result.error
  };
}

async function executePnL(userId: string): Promise<CommandResult> {
  const result = await calculatePnL(userId);

  if (result.success) {
    const formattedPnL = await formatPnL(result);
    return {
      success: true,
      message: formattedPnL,
      data: {
        totalCostBasis: result.totalCostBasis,
        totalCurrentValue: result.totalCurrentValue,
        totalPnL: result.totalPnL,
        totalPnLPercent: result.totalPnLPercent,
        positions: result.positions,
        usdtBalance: result.usdtBalance
      }
    };
  } else {
    return {
      success: false,
      message: result.message,
      data: result.error
    };
  }
}

function showHelp(): CommandResult {
  const helpText = `
📚 AVAILABLE COMMANDS:
────────────────────
/portfolio                       - Show current portfolio
/pnl                            - Show P&L analysis with weighted average
/buy-in-usdt <SYMBOL> <AMOUNT>   - Buy asset with USDT (min $5)
  Example: /buy-in-usdt ASTER 10
/sell-in-usdt <SYMBOL> <AMOUNT>  - Sell asset for USDT (min $5)
  Example: /sell-in-usdt ASTER 5
/buy <SYMBOL> <QUANTITY>         - Buy specific amount of asset
  Example: /buy ASTER 2.5
/sell <SYMBOL> <QUANTITY>        - Sell specific amount of asset
  Example: /sell ASTER 2.5
/help                            - Show this help message
`;

  return {
    success: true,
    message: helpText
  };
}

// ============ MAIN PROCESS FUNCTION ============

export async function processCommand(command: Command): Promise<CommandResult> {
  const cmd = command.command.toLowerCase();
  const args = command.args;
  const userId = command.userId;

  console.log(`\n🔄 Processing for userId ${userId}: ${command.command} ${args.join(' ')}`);

  // Validate userId first
  if (!userId || !/^\d+$/.test(userId)) {
    return {
      success: false,
      message: '❌ Invalid userId: must be numeric'
    };
  }

  switch (cmd) {
    case '/portfolio':
      return await executePortfolio(userId);

    case '/pnl':
      return await executePnL(userId);

    case '/buy-in-usdt':
      if (args.length !== 2) {
        return { success: false, message: '❌ Usage: /buy-in-usdt <SYMBOL> <AMOUNT>' };
      }
      return await executeBuyInUSDT(userId, args[0], parseFloat(args[1]));

    case '/sell-in-usdt':
      if (args.length !== 2) {
        return { success: false, message: '❌ Usage: /sell-in-usdt <SYMBOL> <AMOUNT>' };
      }
      return await executeSellInUSDT(userId, args[0], parseFloat(args[1]));

    case '/buy':
      if (args.length !== 2) {
        return { success: false, message: '❌ Usage: /buy <SYMBOL> <QUANTITY>' };
      }
      return await executeBuy(userId, args[0], parseFloat(args[1]));

    case '/sell':
      if (args.length !== 2) {
        return { success: false, message: '❌ Usage: /sell <SYMBOL> <QUANTITY>' };
      }
      return await executeSell(userId, args[0], parseFloat(args[1]));

    case '/help':
      return showHelp();

    default:
      return {
        success: false,
        message: `❌ Unknown command: ${command.command}. Use /help to see available commands`
      };
  }
}

// ============ CLI ENTRY POINT ============

async function main() {
  const jsonFile = process.argv[2];

  if (!jsonFile) {
    console.error('❌ Please provide a JSON file path');
    console.log('Usage: bun run src/process.ts commands.json');
    process.exit(1);
  }

  try {
    const jsonContent = fs.readFileSync(jsonFile, 'utf-8');
    const commands: Command[] = JSON.parse(jsonContent);

    console.log(`📋 Processing ${commands.length} commands from ${jsonFile}`);

    for (const command of commands) {
      const result = await processCommand(command);

      console.log(result.message);

      if (result.data) {
        console.log('📊 Details:', JSON.stringify(result.data, null, 2));
      }

      // Add small delay between commands to avoid rate limiting
      if (commands.indexOf(command) < commands.length - 1) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }

    console.log('\n✅ All commands processed');

  } catch (error) {
    console.error('❌ Error processing file:', error);
    process.exit(1);
  }
}

