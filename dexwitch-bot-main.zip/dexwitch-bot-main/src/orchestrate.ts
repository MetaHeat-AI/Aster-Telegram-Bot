import { parseMessage } from './parser';
import { processCommand } from './process';

interface TelegramMessage {
  message_id: number;
  from: {
    id: number;
    is_bot: boolean;
    first_name: string;
    username?: string;
    language_code?: string;
  };
  chat: {
    id: number;
    first_name: string;
    username?: string;
    type: string;
  };
  date: number;
  text: string;
}

interface TelegramUpdate {
  update_id: number;
  message?: TelegramMessage;
}

interface OrchestrationResult {
  success: boolean;
  message: string;
  data?: any;
}

export async function orchestrateCommand(userId: string, text: string): Promise<OrchestrationResult> {
  try {
    console.log(`Processing command for user ${userId}: "${text}"`);

    // Parse the message (parser doesn't need userId)
    const parseResult = parseMessage(text);

    if (!parseResult.success) {
      return {
        success: false,
        message: parseResult.response
      };
    }

    // Handle /help directly (no processing needed)
    if (!parseResult.command) {
      return {
        success: true,
        message: parseResult.response
      };
    }

    // Add userId to the parsed command
    const commandWithUser = {
      ...parseResult.command,
      userId: userId
    };

    // Process the command
    console.log('Executing command:', commandWithUser);
    const result = await processCommand(commandWithUser);

    return {
      success: result.success,
      message: result.message,
      data: result.data
    };

  } catch (error) {
    console.error('Error orchestrating command:', error);
    return {
      success: false,
      message: 'An error occurred while processing your request'
    };
  }
}

export async function handleTelegramUpdate(update: TelegramUpdate): Promise<string> {
  try {
    // Check if update has a message
    if (!update.message || !update.message.text) {
      return '❌ No message text found';
    }

    const message = update.message;
    const userId = message.from.id.toString();
    const text = message.text;

    const result = await orchestrateCommand(userId, text);

    if (result.success) {
      return result.message;
    } else {
      return `❌ ${result.message}`;
    }

  } catch (error) {
    console.error('Error handling Telegram update:', error);
    return '❌ An error occurred while processing your request';
  }
}

// CLI functionality for testing
async function main() {
  const userId = process.argv[2];
  const text = process.argv[3];

  if (!userId || !text) {
    console.log('Usage: bun run src/orchestrate.ts <userId> "<command>"');
    console.log('Examples:');
    console.log('  bun run src/orchestrate.ts 849606703 "/help"');
    console.log('  bun run src/orchestrate.ts 849606703 "/portfolio"');
    console.log('  bun run src/orchestrate.ts 849606703 "/buy-in-usdt ASTER 10"');
    process.exit(1);
  }

  console.log(`Orchestrating command for user ${userId}: "${text}"`);

  try {
    const result = await orchestrateCommand(userId, text);
    console.log(JSON.stringify(result, null, 2));
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
}

export async function sendTelegramMessage(chatId: number, text: string): Promise<void> {
  const botToken = '8329616479:AAELKuBfVseIXbgutCgWncv_spSyVVmyIvM';

  try {
    const response = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: text,
        parse_mode: 'HTML'
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Failed to send Telegram message:', errorText);
    } else {
      console.log('Message sent successfully to chat', chatId);
    }
  } catch (error) {
    console.error('Error sending Telegram message:', error);
  }
}

// Only run main if this is the entry point
if (require.main === module) {
  main();
}