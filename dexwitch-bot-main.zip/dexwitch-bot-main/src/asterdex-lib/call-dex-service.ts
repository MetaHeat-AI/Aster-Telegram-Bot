import fs from 'fs';
import path from 'path';
import { createSignature, ApiCredentials } from './utils.js';

export interface DexApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: any;
  status?: number;
  message?: string;
}

export class CallDexService {
  private static readonly SPOT_BASE_URL = 'https://sapi.asterdex.com';
  private static readonly FUTURES_BASE_URL = 'https://fapi.asterdex.com';

  /**
   * Get API credentials for a specific user ID
   * TODO: Replace with database lookup and decryption
   */
  private static async getCredentialsByUserId(userId: string): Promise<ApiCredentials | null> {
    try {
      // Strict validation: userId must be numeric and non-empty
      if (!userId || !/^\d+$/.test(userId)) {
        throw new Error('Invalid userId: must be numeric');
      }

      const secretPath = path.join(process.cwd(), `${userId}-secret.json`);
      console.log('checking secretPath', secretPath);
      // Strict file existence check
      if (!fs.existsSync(secretPath)) {
        throw new Error(`Credentials not found for userId: ${userId}`);
      }

      const secretContent = fs.readFileSync(secretPath, 'utf-8');
      const credentials = JSON.parse(secretContent);

      // Strict validation: credentials must have required fields
      if (!credentials.key || !credentials.secret) {
        throw new Error('Invalid credentials: missing key or secret');
      }

      // Strict validation: credentials must be strings with minimum length
      if (typeof credentials.key !== 'string' || credentials.key.length < 32) {
        throw new Error('Invalid API key format');
      }

      if (typeof credentials.secret !== 'string' || credentials.secret.length < 32) {
        throw new Error('Invalid API secret format');
      }

      return {
        key: credentials.key,
        secret: credentials.secret
      };

    } catch (error) {
      // NO FALLBACKS - Fail explicitly
      return null;
    }
  }

  /**
   * Make authenticated API call to spot trading endpoints
   */
  static async callSpotApi<T>(
    userId: string,
    endpoint: string,
    method: 'GET' | 'POST' = 'GET',
    params: Record<string, any> = {}
  ): Promise<DexApiResponse<T>> {
    try {
      // Strict credential validation - NO FALLBACKS
      const credentials = await this.getCredentialsByUserId(userId);
      if (!credentials) {
        return {
          success: false,
          message: `Failed to get credentials for userId: ${userId}`,
          error: 'CREDENTIAL_ERROR'
        };
      }
      const timestamp = Date.now();

      const allParams = {
        ...params,
        timestamp: timestamp
      };

      const queryString = Object.entries(allParams)
        .map(([key, value]) => `${key}=${value}`)
        .join('&');

      const signature = createSignature(queryString, credentials.secret);

      const url = `${this.SPOT_BASE_URL}${endpoint}`;
      const requestOptions: RequestInit = {
        method: method,
        headers: {
          'X-MBX-APIKEY': credentials.key,
          'Content-Type': method === 'POST'
            ? 'application/x-www-form-urlencoded'
            : 'application/json'
        }
      };

      if (method === 'GET') {
        const fullUrl = `${url}?${queryString}&signature=${signature}`;
        const response = await fetch(fullUrl, requestOptions);
        return await this.handleResponse<T>(response);
      } else {
        requestOptions.body = `${queryString}&signature=${signature}`;
        const response = await fetch(url, requestOptions);
        return await this.handleResponse<T>(response);
      }

    } catch (error) {
      return {
        success: false,
        error: error,
        message: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  /**
   * Make public API call to futures endpoints (no authentication)
   */
  static async callFuturesApi<T>(
    endpoint: string,
    params: Record<string, any> = {}
  ): Promise<DexApiResponse<T>> {
    try {
      const queryString = Object.entries(params)
        .map(([key, value]) => `${key}=${value}`)
        .join('&');

      const url = queryString
        ? `${this.FUTURES_BASE_URL}${endpoint}?${queryString}`
        : `${this.FUTURES_BASE_URL}${endpoint}`;

      const response = await fetch(url);
      return await this.handleResponse<T>(response);

    } catch (error) {
      return {
        success: false,
        error: error,
        message: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  /**
   * Handle HTTP response and parse JSON
   */
  private static async handleResponse<T>(response: Response): Promise<DexApiResponse<T>> {
    try {
      const responseText = await response.text();

      if (response.ok) {
        const data = JSON.parse(responseText);
        return {
          success: true,
          data: data,
          status: response.status
        };
      } else {
        const errorData = responseText ? JSON.parse(responseText) : {};
        return {
          success: false,
          error: errorData,
          status: response.status,
          message: errorData.msg || `HTTP ${response.status}`
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error,
        status: response.status,
        message: 'Failed to parse response'
      };
    }
  }

  // === SPOT TRADING METHODS ===

  /**
   * Place buy order by USDT amount
   */
  static async buyWithUSDT(userId: string, symbol: string, usdtAmount: number) {
    // Strict validation - NO AUTO-CORRECTIONS
    if (!userId || !symbol || !usdtAmount || usdtAmount <= 0) {
      return {
        success: false,
        message: 'Invalid parameters: userId, symbol, and positive usdtAmount required',
        error: 'VALIDATION_ERROR'
      };
    }

    return await this.callSpotApi(userId, '/api/v1/order', 'POST', {
      symbol: symbol,
      side: 'BUY',
      type: 'MARKET',
      quoteOrderQty: usdtAmount.toString()
    });
  }

  /**
   * Place buy order by quantity
   */
  static async buyByQuantity(userId: string, symbol: string, quantity: number) {
    // Strict validation - NO AUTO-CORRECTIONS
    if (!userId || !symbol || !quantity || quantity <= 0) {
      return {
        success: false,
        message: 'Invalid parameters: userId, symbol, and positive quantity required',
        error: 'VALIDATION_ERROR'
      };
    }

    return await this.callSpotApi(userId, '/api/v1/order', 'POST', {
      symbol: symbol,
      side: 'BUY',
      type: 'MARKET',
      quantity: quantity.toString()
    });
  }

  /**
   * Place sell order by USDT amount
   */
  static async sellWithUSDT(userId: string, symbol: string, usdtAmount: number) {
    // Strict validation - NO AUTO-CORRECTIONS
    if (!userId || !symbol || !usdtAmount || usdtAmount <= 0) {
      return {
        success: false,
        message: 'Invalid parameters: userId, symbol, and positive usdtAmount required',
        error: 'VALIDATION_ERROR'
      };
    }

    return await this.callSpotApi(userId, '/api/v1/order', 'POST', {
      symbol: symbol,
      side: 'SELL',
      type: 'MARKET',
      quoteOrderQty: usdtAmount.toString()
    });
  }

  /**
   * Place sell order by quantity
   */
  static async sellByQuantity(userId: string, symbol: string, quantity: number) {
    // Strict validation - NO AUTO-CORRECTIONS
    if (!userId || !symbol || !quantity || quantity <= 0) {
      return {
        success: false,
        message: 'Invalid parameters: userId, symbol, and positive quantity required',
        error: 'VALIDATION_ERROR'
      };
    }

    return await this.callSpotApi(userId, '/api/v1/order', 'POST', {
      symbol: symbol,
      side: 'SELL',
      type: 'MARKET',
      quantity: quantity.toString()
    });
  }

  /**
   * Get account information and balances
   */
  static async getAccount(userId: string) {
    if (!userId) {
      return {
        success: false,
        message: 'Invalid parameter: userId required',
        error: 'VALIDATION_ERROR'
      };
    }

    return await this.callSpotApi(userId, '/api/v1/account');
  }

  /**
   * Get trade history for a symbol
   */
  static async getTradeHistory(userId: string, symbol: string, limit: number = 500) {
    if (!userId || !symbol) {
      return {
        success: false,
        message: 'Invalid parameters: userId and symbol required',
        error: 'VALIDATION_ERROR'
      };
    }

    return await this.callSpotApi(userId, '/api/v1/userTrades', 'GET', {
      symbol: symbol,
      limit: limit
    });
  }

  /**
   * Alias for getTradeHistory (for consistency with PnL module)
   */
  static async getUserTrades(userId: string, symbol: string, limit: number = 500) {
    return await this.getTradeHistory(userId, symbol, limit);
  }

  // === MARKET DATA METHODS ===

  /**
   * Get current price for symbol
   */
  static async getCurrentPrice(symbol: string) {
    return await this.callFuturesApi('/fapi/v1/ticker/price', { symbol });
  }

  /**
   * Get 24hr ticker statistics
   */
  static async get24hrTicker(symbol: string) {
    return await this.callFuturesApi('/fapi/v1/ticker/24hr', { symbol });
  }

  /**
   * Get order book depth
   */
  static async getOrderBook(symbol: string, limit: number = 5) {
    return await this.callFuturesApi('/fapi/v1/depth', { symbol, limit });
  }

  /**
   * Get all price tickers
   */
  static async getAllPrices() {
    return await this.callFuturesApi('/fapi/v1/ticker/price');
  }
}