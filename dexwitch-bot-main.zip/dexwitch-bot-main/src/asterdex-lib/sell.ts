import { CallDexService } from './call-dex-service.js';

export interface SellResult {
  success: boolean;
  message: string;
  orderId?: string;
  executedQty?: string;
  avgPrice?: string;
  cumQuote?: string;
  error?: any;
}

export async function sellWithUSDT(userId: string, symbol: string, usdtAmount: number): Promise<SellResult> {
  const asset = symbol.replace('USDT', '');
  const result = await CallDexService.sellWithUSDT(userId, symbol, usdtAmount);

  if (result.success && result.data) {
    const data = result.data as any;
    return {
      success: true,
      message: `✅ Sold $${usdtAmount} worth of ${asset}`,
      orderId: data.orderId?.toString(),
      executedQty: data.origQty,
      avgPrice: data.avgPrice,
      cumQuote: data.cumQuote
    };
  } else {
    return {
      success: false,
      message: result.message || `❌ Sell failed`,
      error: result.error
    };
  }
}

export async function sellByQuantity(userId: string, symbol: string, quantity: number): Promise<SellResult> {
  const asset = symbol.replace('USDT', '');
  const result = await CallDexService.sellByQuantity(userId, symbol, quantity);

  if (result.success && result.data) {
    const data = result.data as any;
    return {
      success: true,
      message: `✅ Sold ${quantity} ${asset}`,
      orderId: data.orderId?.toString(),
      executedQty: data.executedQty,
      avgPrice: data.avgPrice,
      cumQuote: data.cumQuote
    };
  } else {
    return {
      success: false,
      message: result.message || `❌ Sell failed`,
      error: result.error
    };
  }
}