import { Pool, PoolClient } from 'pg';

export interface AsterDexCredentials {
  key: string;
  secret: string;
}

export class DbService {
  private static pool: Pool | null = null;

  private static getPool(): Pool {
    if (!this.pool) {
      const connectionString = process.env.PG_URL;
      if (!connectionString) {
        throw new Error('PG_URL environment variable is not set');
      }

      this.pool = new Pool({
        connectionString,
        ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
        max: 10,
        idleTimeoutMillis: 30000,
        connectionTimeoutMillis: 2000,
      });
    }
    return this.pool;
  }

  /**
   * Initialize database table if it doesn't exist
   */
  static async initializeTable(): Promise<void> {
    const pool = this.getPool();
    const client: PoolClient = await pool.connect();

    try {
      await client.query(`
        CREATE TABLE IF NOT EXISTS user_asterdex_keys (
          user_id VARCHAR(50) PRIMARY KEY,
          api_key VARCHAR(255) NOT NULL,
          api_secret VARCHAR(255) NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Create index on user_id if it doesn't exist
      await client.query(`
        CREATE INDEX IF NOT EXISTS idx_user_asterdex_keys_user_id
        ON user_asterdex_keys(user_id)
      `);

      console.log('✅ Database table initialized successfully');
    } catch (error) {
      console.error('❌ Failed to initialize database table:', error);
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Set AsterDex API credentials for a user
   */
  static async setAsterDexKey(userId: string, credentials: AsterDexCredentials): Promise<boolean> {
    if (!userId || !/^\d+$/.test(userId)) {
      throw new Error('Invalid userId: must be numeric');
    }

    if (!credentials.key || !credentials.secret) {
      throw new Error('Both API key and secret are required');
    }

    const pool = this.getPool();
    const client: PoolClient = await pool.connect();

    try {
      const query = `
        INSERT INTO user_asterdex_keys (user_id, api_key, api_secret, updated_at)
        VALUES ($1, $2, $3, CURRENT_TIMESTAMP)
        ON CONFLICT (user_id)
        DO UPDATE SET
          api_key = EXCLUDED.api_key,
          api_secret = EXCLUDED.api_secret,
          updated_at = CURRENT_TIMESTAMP
      `;

      await client.query(query, [userId, credentials.key, credentials.secret]);
      console.log(`✅ API credentials stored for user ${userId}`);
      return true;
    } catch (error) {
      console.error(`❌ Failed to store credentials for user ${userId}:`, error);
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Get AsterDex API credentials for a user
   */
  static async getAsterDexKey(userId: string): Promise<AsterDexCredentials | null> {
    if (!userId || !/^\d+$/.test(userId)) {
      throw new Error('Invalid userId: must be numeric');
    }

    const pool = this.getPool();
    const client: PoolClient = await pool.connect();

    try {
      const query = 'SELECT api_key, api_secret FROM user_asterdex_keys WHERE user_id = $1';
      const result = await client.query(query, [userId]);

      if (result.rows.length === 0) {
        console.log(`⚠️ No credentials found for user ${userId}`);
        return null;
      }

      const row = result.rows[0];
      return {
        key: row.api_key,
        secret: row.api_secret
      };
    } catch (error) {
      console.error(`❌ Failed to retrieve credentials for user ${userId}:`, error);
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Remove AsterDex API credentials for a user
   */
  static async removeAsterDexKey(userId: string): Promise<boolean> {
    if (!userId || !/^\d+$/.test(userId)) {
      throw new Error('Invalid userId: must be numeric');
    }

    const pool = this.getPool();
    const client: PoolClient = await pool.connect();

    try {
      const query = 'DELETE FROM user_asterdex_keys WHERE user_id = $1';
      const result = await client.query(query, [userId]);

      if (result.rowCount === 0) {
        console.log(`⚠️ No credentials found to remove for user ${userId}`);
        return false;
      }

      console.log(`✅ Credentials removed for user ${userId}`);
      return true;
    } catch (error) {
      console.error(`❌ Failed to remove credentials for user ${userId}:`, error);
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Close database connection pool
   */
  static async close(): Promise<void> {
    if (this.pool) {
      await this.pool.end();
      this.pool = null;
      console.log('✅ Database connection pool closed');
    }
  }

  /**
   * Test database connection
   */
  static async testConnection(): Promise<boolean> {
    try {
      const pool = this.getPool();
      const client = await pool.connect();

      await client.query('SELECT NOW()');
      client.release();

      console.log('✅ Database connection test successful');
      return true;
    } catch (error) {
      console.error('❌ Database connection test failed:', error);
      return false;
    }
  }
}