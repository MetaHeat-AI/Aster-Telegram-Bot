import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export interface ApiCredentials {
  key: string;
  secret: string;
}

export async function loadCredentials(): Promise<ApiCredentials> {
  const secretPath = path.join(__dirname, '../../secret.json');
  const secretContent = fs.readFileSync(secretPath, 'utf-8');
  return JSON.parse(secretContent);
}

export function createSignature(queryString: string, secret: string): string {
  return crypto.createHmac('sha256', secret).update(queryString).digest('hex');
}

export async function getCurrentPrice(symbol: string): Promise<number> {
  try {
    const futuresBaseURL = 'https://fapi.asterdex.com';
    const response = await fetch(`${futuresBaseURL}/fapi/v1/ticker/price?symbol=${symbol}`);

    if (!response.ok) {
      return 0;
    }

    const data = await response.json();
    return parseFloat(data.price);
  } catch (error) {
    return 0;
  }
}