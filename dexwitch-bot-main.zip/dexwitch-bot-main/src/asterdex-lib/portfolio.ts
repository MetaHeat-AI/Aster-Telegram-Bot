import { CallDexService } from './call-dex-service.js';

export interface Balance {
  asset: string;
  free: string;
  locked: string;
}

export interface PortfolioResult {
  success: boolean;
  message: string;
  balances?: Balance[];
  accountInfo?: any;
  error?: any;
}

export async function getPortfolio(userId: string): Promise<PortfolioResult> {
  // Strict validation - NO FALLBACKS
  if (!userId) {
    return {
      success: false,
      message: '❌ Invalid parameter: userId required',
      error: 'VALIDATION_ERROR'
    };
  }

  const result = await CallDexService.getAccount(userId);

  if (result.success && result.data) {
    const data = result.data as any;
    // Filter non-zero balances
    const nonZeroBalances = data.balances.filter((balance: Balance) =>
      parseFloat(balance.free) > 0 || parseFloat(balance.locked) > 0
    );

    return {
      success: true,
      message: '✅ Portfolio retrieved successfully',
      balances: nonZeroBalances,
      accountInfo: data
    };
  } else {
    return {
      success: false,
      message: result.message || '❌ Failed to get portfolio',
      error: result.error
    };
  }
}

export function formatPortfolio(result: PortfolioResult): string {
  if (!result.success || !result.balances) {
    return result.message;
  }

  let output = '\n=== PORTFOLIO ===\n';

  result.balances.forEach(balance => {
    output += `${balance.asset}: ${balance.free}\n`;
  });

  return output;
}