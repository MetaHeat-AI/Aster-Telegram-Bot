import { loadCredentials, createSignature, getCurrentPrice } from './utils.js';

export interface PriceData {
  symbol: string;
  currentPrice: number;
  highPrice: number;
  lowPrice: number;
  priceChange: number;
  priceChangePercent: number;
  volume: number;
  quoteVolume: number;
  bestBid?: number;
  bestAsk?: number;
  spread?: number;
}

export interface PricesResult {
  success: boolean;
  message: string;
  prices?: PriceData[];
  error?: any;
}

async function get24hrTicker(symbol: string) {
  try {
    const futuresBaseURL = 'https://fapi.asterdex.com';
    const response = await fetch(`${futuresBaseURL}/fapi/v1/ticker/24hr?symbol=${symbol}`);

    if (!response.ok) {
      return null;
    }

    const data = await response.json();
    return data;
  } catch (error) {
    return null;
  }
}

async function getOrderBook(symbol: string) {
  try {
    const futuresBaseURL = 'https://fapi.asterdex.com';
    const response = await fetch(`${futuresBaseURL}/fapi/v1/depth?symbol=${symbol}&limit=5`);

    if (!response.ok) {
      return null;
    }

    const data = await response.json();
    return data;
  } catch (error) {
    return null;
  }
}

export async function getPrices(assets: string[]): Promise<PricesResult> {
  try {
    const pricesData: PriceData[] = [];

    for (const asset of assets) {
      const symbol = asset.toUpperCase() + 'USDT';

      // Get 24hr ticker data
      const ticker = await get24hrTicker(symbol);
      if (!ticker) {
        continue; // Skip this asset if no data
      }

      // Get order book for bid/ask spread
      const orderBook = await getOrderBook(symbol);

      const priceData: PriceData = {
        symbol: symbol,
        currentPrice: parseFloat(ticker.lastPrice),
        highPrice: parseFloat(ticker.highPrice),
        lowPrice: parseFloat(ticker.lowPrice),
        priceChange: parseFloat(ticker.priceChange),
        priceChangePercent: parseFloat(ticker.priceChangePercent),
        volume: parseFloat(ticker.volume),
        quoteVolume: parseFloat(ticker.quoteVolume)
      };

      // Add order book data if available
      if (orderBook) {
        const bestBid = orderBook.bids[0] ? parseFloat(orderBook.bids[0][0]) : 0;
        const bestAsk = orderBook.asks[0] ? parseFloat(orderBook.asks[0][0]) : 0;

        if (bestBid > 0 && bestAsk > 0) {
          priceData.bestBid = bestBid;
          priceData.bestAsk = bestAsk;
          priceData.spread = bestAsk - bestBid;
        }
      }

      pricesData.push(priceData);
    }

    return {
      success: true,
      message: `✅ Retrieved prices for ${pricesData.length} assets`,
      prices: pricesData
    };

  } catch (error) {
    return {
      success: false,
      message: `❌ Error getting prices: ${error instanceof Error ? error.message : 'Unknown error'}`,
      error: error
    };
  }
}

export function formatPrices(result: PricesResult): string {
  if (!result.success || !result.prices) {
    return result.message;
  }

  let output = '\n=== SPOT MARKET PRICES ===\n';
  output += '─'.repeat(80) + '\n';

  for (const price of result.prices) {
    output += `\n📊 ${price.symbol}:\n`;
    output += `  Current Price: $${price.currentPrice.toFixed(6)} USDT\n`;
    output += `  24h High:      $${price.highPrice.toFixed(6)} USDT\n`;
    output += `  24h Low:       $${price.lowPrice.toFixed(6)} USDT\n`;
    output += `  24h Change:    ${price.priceChangePercent.toFixed(2)}%\n`;
    output += `  24h Volume:    ${price.volume.toFixed(2)} ${price.symbol.replace('USDT', '')}\n`;
    output += `  24h Quote Vol: $${price.quoteVolume.toFixed(2)} USDT\n`;

    if (price.bestBid && price.bestAsk && price.spread) {
      output += `\n  Order Book:\n`;
      output += `  Best Bid: $${price.bestBid.toFixed(6)} USDT\n`;
      output += `  Best Ask: $${price.bestAsk.toFixed(6)} USDT\n`;
      output += `  Spread:   $${price.spread.toFixed(6)} (${((price.spread / price.bestAsk) * 100).toFixed(3)}%)\n`;
    }
  }

  output += '\n' + '─'.repeat(80) + '\n';

  return output;
}