import { CallDexService } from './call-dex-service.js';

export interface BuyResult {
  success: boolean;
  message: string;
  orderId?: string;
  executedQty?: string;
  avgPrice?: string;
  cumQuote?: string;
  error?: any;
}

export async function buyWithUSDT(userId: string, symbol: string, usdtAmount: number): Promise<BuyResult> {
  const asset = symbol.replace('USDT', '');
  const result = await CallDexService.buyWithUSDT(userId, symbol, usdtAmount);

  if (result.success && result.data) {
    const data = result.data as any;
    return {
      success: true,
      message: `✅ Bought $${usdtAmount} worth of ${asset}`,
      orderId: data.orderId?.toString(),
      executedQty: data.executedQty,
      avgPrice: data.avgPrice,
      cumQuote: data.cumQuote
    };
  } else {
    return {
      success: false,
      message: result.message || `❌ Buy failed`,
      error: result.error
    };
  }
}

export async function buyByQuantity(userId: string, symbol: string, quantity: number): Promise<BuyResult> {
  const asset = symbol.replace('USDT', '');
  const result = await CallDexService.buyByQuantity(userId, symbol, quantity);

  if (result.success && result.data) {
    const data = result.data as any;
    return {
      success: true,
      message: `✅ Bought ${quantity} ${asset}`,
      orderId: data.orderId?.toString(),
      executedQty: data.executedQty,
      avgPrice: data.avgPrice,
      cumQuote: data.cumQuote
    };
  } else {
    return {
      success: false,
      message: result.message || `❌ Buy failed`,
      error: result.error
    };
  }
}