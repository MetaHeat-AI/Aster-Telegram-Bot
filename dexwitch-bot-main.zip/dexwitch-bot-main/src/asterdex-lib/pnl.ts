import { CallDexService } from './call-dex-service.js';
import { getCurrentPrice } from './utils.js';

interface Trade {
  symbol: string;
  price: string;
  qty: string;
  quoteQty: string;
  time: number;
  buyer: boolean;
  commission: string;
  commissionAsset: string;
}

interface Position {
  asset: string;
  quantity: number;
  totalCost: number;
  avgPrice: number;
  trades: Trade[];
}

export interface PnLResult {
  success: boolean;
  message: string;
  positions?: Position[];
  totalCostBasis?: number;
  totalCurrentValue?: number;
  totalPnL?: number;
  totalPnLPercent?: number;
  usdtBalance?: number;
  error?: any;
}

export async function calculatePnL(userId: string): Promise<PnLResult> {
  try {
    // Get current balances
    const accountResult = await CallDexService.getAccount(userId);
    if (!accountResult.success || !accountResult.data) {
      return {
        success: false,
        message: accountResult.message || '❌ Failed to get account data',
        error: accountResult.error
      };
    }

    const accountData = accountResult.data as any;
    const positions: Map<string, Position> = new Map();

    // Process each non-zero balance
    for (const balance of accountData.balances) {
      const amount = parseFloat(balance.free) + parseFloat(balance.locked || '0');
      if (amount > 0 && balance.asset !== 'USDT') {
        const symbol = `${balance.asset}USDT`;

        // Get trade history
        const tradesResult = await CallDexService.getUserTrades(userId, symbol);
        const trades = tradesResult.success ? tradesResult.data || [] : [];

        let runningQuantity = 0;
        let runningCostBasis = 0;
        let weightedAvgPrice = 0;

        // Sort trades by time (oldest first) for proper accounting
        const sortedTrades = (trades as Trade[]).sort((a: Trade, b: Trade) => a.time - b.time);

        for (const trade of sortedTrades) {
          const qty = parseFloat(trade.qty);
          const value = parseFloat(trade.quoteQty);

          if (trade.buyer) {
            // BUY: Add to position with weighted average
            const newTotalValue = runningCostBasis + value;
            const newTotalQty = runningQuantity + qty;

            runningQuantity = newTotalQty;
            runningCostBasis = newTotalValue;
            weightedAvgPrice = newTotalQty > 0 ? newTotalValue / newTotalQty : 0;
          } else {
            // SELL: Reduce position using weighted average cost
            const soldValue = qty * weightedAvgPrice;

            runningQuantity -= qty;
            runningCostBasis -= soldValue;

            // Ensure we don't go negative due to rounding
            if (runningQuantity <= 0) {
              runningQuantity = 0;
              runningCostBasis = 0;
              weightedAvgPrice = 0;
            }
          }
        }

        // The remaining cost basis is what's left after all trades
        const remainingCostBasis = Math.max(0, runningCostBasis);

        positions.set(balance.asset, {
          asset: balance.asset,
          quantity: amount,
          totalCost: remainingCostBasis,
          avgPrice: weightedAvgPrice,
          trades: trades as Trade[]
        });
      }
    }

    // Calculate P&L for each position
    let totalCostBasis = 0;
    let totalCurrentValue = 0;
    const positionResults: Position[] = [];

    for (const [asset, position] of Array.from(positions)) {
      const symbol = `${asset}USDT`;
      const currentPrice = await getCurrentPrice(symbol);
      const currentValue = position.quantity * currentPrice;

      totalCostBasis += position.totalCost;
      totalCurrentValue += currentValue;
      positionResults.push(position);
    }

    // Get USDT balance
    const usdtBalance = accountData.balances.find((b: any) => b.asset === 'USDT');
    const usdtAmount = usdtBalance ? parseFloat(usdtBalance.free) + parseFloat(usdtBalance.locked || '0') : 0;

    const totalPnL = totalCurrentValue - totalCostBasis;
    const totalPnLPercent = totalCostBasis > 0 ? (totalPnL / totalCostBasis * 100) : 0;

    return {
      success: true,
      message: '✅ P&L calculated successfully',
      positions: positionResults,
      totalCostBasis,
      totalCurrentValue,
      totalPnL,
      totalPnLPercent,
      usdtBalance: usdtAmount
    };

  } catch (error) {
    return {
      success: false,
      message: `❌ Error calculating P&L: ${error instanceof Error ? error.message : 'Unknown error'}`,
      error: error
    };
  }
}

export async function formatPnL(result: PnLResult): Promise<string> {
  if (!result.success) {
    return result.message;
  }

  let output = '\n=== PORTFOLIO P&L ANALYSIS ===\n';
  output += '═'.repeat(80) + '\n';

  if (result.usdtBalance && result.usdtBalance > 0) {
    output += `\n💵 USDT Balance: $${result.usdtBalance.toFixed(2)}\n`;
  }

  output += '\n' + '─'.repeat(80) + '\n';
  output += 'Asset     Quantity        Avg Cost    Current Price   Value       P&L        %\n';
  output += '─'.repeat(80) + '\n';

  if (result.positions) {
    for (const position of result.positions) {
      const symbol = `${position.asset}USDT`;
      const currentPrice = await getCurrentPrice(symbol);
      const currentValue = position.quantity * currentPrice;
      const pnl = currentValue - position.totalCost;
      const pnlPercent = position.totalCost > 0 ? (pnl / position.totalCost * 100) : 0;

      output += `${position.asset.padEnd(8)} ${position.quantity.toFixed(4).padEnd(14)} ` +
        `$${position.avgPrice.toFixed(4).padEnd(10)} ` +
        `$${currentPrice.toFixed(4).padEnd(14)} ` +
        `$${currentValue.toFixed(2).padEnd(10)} ` +
        `${pnl >= 0 ? '+' : ''}$${pnl.toFixed(2).padEnd(10)} ` +
        `${pnl >= 0 ? '🟢' : '🔴'} ${pnlPercent >= 0 ? '+' : ''}${pnlPercent.toFixed(1)}%\n`;
    }
  }

  output += '─'.repeat(80) + '\n';
  output += '\n📊 SUMMARY:\n';
  output += `Total Cost Basis:    $${result.totalCostBasis?.toFixed(2) || '0.00'}\n`;
  output += `Current Value:       $${result.totalCurrentValue?.toFixed(2) || '0.00'}\n`;
  output += `Unrealized P&L:      ${result.totalPnL && result.totalPnL >= 0 ? '+' : ''}$${result.totalPnL?.toFixed(2) || '0.00'} (${result.totalPnLPercent && result.totalPnLPercent >= 0 ? '+' : ''}${result.totalPnLPercent?.toFixed(1) || '0.0'}%)\n`;

  if (result.usdtBalance) {
    const totalPortfolio = (result.totalCurrentValue || 0) + result.usdtBalance;
    output += `Total Portfolio:     $${totalPortfolio.toFixed(2)} (including USDT)\n`;
  }

  output += '\n' + '═'.repeat(80);
  return output;
}