import { processCommand } from './process';

interface TelegramMessage {
  message_id: number;
  from: {
    id: number;
    is_bot: boolean;
    first_name: string;
    username?: string;
    language_code?: string;
  };
  chat: {
    id: number;
    first_name: string;
    username?: string;
    type: string;
  };
  date: number;
  text: string;
}

interface TelegramUpdate {
  update_id: number;
  message?: TelegramMessage;
}

interface ParsedCommand {
  command: string;
  args: string[];
}

interface ParseResult {
  success: boolean;
  command?: ParsedCommand;
  response: string;
}

const HELP_MESSAGE = `
📚 AVAILABLE COMMANDS:
────────────────────
/portfolio                       - Show current portfolio
/pnl                            - Show P&L analysis with weighted average
/buy-in-usdt <SYMBOL> <AMOUNT>   - Buy asset with USDT (min $5)
  Example: /buy-in-usdt ASTER 10
/sell-in-usdt <SYMBOL> <AMOUNT>  - Sell asset for USDT (min $5)
  Example: /sell-in-usdt ASTER 5
/buy <SYMBOL> <QUANTITY>         - Buy specific amount of asset
  Example: /buy ASTER 2.5
/sell <SYMBOL> <QUANTITY>        - Sell specific amount of asset
  Example: /sell ASTER 2.5
/help                            - Show this help message
`;

export function parseMessage(text: string): ParseResult {
  // Clean and normalize the message
  const cleanText = text.trim();

  // Check if it's a command (starts with /)
  if (!cleanText.startsWith('/')) {
    return {
      success: false,
      response: `❌ Unknown command. ${HELP_MESSAGE}`
    };
  }

  // Split the command and arguments
  const parts = cleanText.split(/\s+/);
  const command = parts[0].toLowerCase();
  const args = parts.slice(1);

  // Validate known commands
  const validCommands = ['/portfolio', '/pnl', '/buy-in-usdt', '/sell-in-usdt', '/buy', '/sell', '/help'];

  if (!validCommands.includes(command)) {
    return {
      success: false,
      response: `❌ Unknown command: ${command}. ${HELP_MESSAGE}`
    };
  }

  // Handle /help directly
  if (command === '/help') {
    return {
      success: true,
      response: HELP_MESSAGE
    };
  }

  // Create parsed command
  const parsedCommand: ParsedCommand = {
    command: command,
    args: args
  };

  return {
    success: true,
    command: parsedCommand,
    response: '' // Will be filled by processCommand
  };
}

export async function handleTelegramUpdate(update: TelegramUpdate): Promise<string> {
  try {
    // Check if update has a message
    if (!update.message || !update.message.text) {
      return '❌ No message text found';
    }

    const message = update.message;
    const userId = message.from.id;
    const text = message.text;

    console.log(`Processing message from user ${userId}: "${text}"`);

    // Parse the message
    const parseResult = parseMessage(text);

    if (!parseResult.success) {
      // Return error or help message
      return parseResult.response;
    }

    // Handle /help directly
    if (!parseResult.command) {
      return parseResult.response;
    }

    // Add userId to the parsed command and process
    const commandWithUser = {
      ...parseResult.command,
      userId: userId.toString()
    };
    console.log('Executing command:', commandWithUser);
    const result = await processCommand(commandWithUser);

    if (result.success) {
      return result.message;
    } else {
      return `❌ ${result.message}`;
    }

  } catch (error) {
    console.error('Error handling Telegram update:', error);
    return '❌ An error occurred while processing your request';
  }
}

export async function sendTelegramMessage(chatId: number, text: string): Promise<void> {
  const botToken = '8329616479:AAELKuBfVseIXbgutCgWncv_spSyVVmyIvM';

  try {
    const response = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: text,
        parse_mode: 'HTML'
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Failed to send Telegram message:', errorText);
    } else {
      console.log('Message sent successfully to chat', chatId);
    }
  } catch (error) {
    console.error('Error sending Telegram message:', error);
  }
}

// CLI functionality for testing
async function main() {
  const command = process.argv[2];
  const userId = process.argv[3] || '849606703'; // Default to your user ID

  if (!command) {
    console.log('Usage: bun run src/parser.ts "<command>" [userId]');
    console.log('Examples:');
    console.log('  bun run src/parser.ts "/help"');
    console.log('  bun run src/parser.ts "/portfolio" 849606703');
    console.log('  bun run src/parser.ts "/buy-in-usdt ASTER 10" 849606703');
    process.exit(1);
  }

  console.log(`Testing command: ${command} for user: ${userId}`);

  const parseResult = parseMessage(command);

  if (!parseResult.success) {
    console.log('Parse failed:', parseResult.response);
    return;
  }

  if (!parseResult.command) {
    console.log('Response:', parseResult.response);
    return;
  }

  try {
    const commandWithUser = {
      ...parseResult.command,
      userId: userId
    };
    const result = await processCommand(commandWithUser);
    console.log('Success:', result.success);
    console.log('Message:', result.message);
    if (result.data) {
      console.log('Data:', JSON.stringify(result.data, null, 2));
    }
  } catch (error) {
    console.error('Error:', error);
  }
}

// Only run main if this is the entry point
if (require.main === module) {
  main();
}