import { VercelRequest, VercelResponse } from '@vercel/node';
import fs from 'fs';
import path from 'path';
import { processCommand } from '../../src/process.js';

const WEBHOOK_SECRET = process.env.TELEGRAM_WEBHOOK_SECRET || '';
const BOT_TOKEN = process.env.BOT_TOKEN || '';

function isValidSecretToken(secretToken: string | undefined): boolean {
  if (!secretToken || !WEBHOOK_SECRET) return false;
  return secretToken === WEBHOOK_SECRET;
}

async function preProcessRequest(req: VercelRequest) {
  const secretToken = req.headers['x-telegram-bot-api-secret-token'] as string | undefined;
  const isTokenValid = isValidSecretToken(secretToken);

  const requestData = {
    method: req.method,
    url: req.url,
    headers: req.headers,
    body: req.body,
    query: req.query,
    timestamp: new Date().toISOString(),
    secretToken: {
      provided: !!secretToken,
      valid: isTokenValid
    }
  };

  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `webhook-${timestamp}.json`;
  const filepath = path.join(process.cwd(), 'request-logger', filename);

  await fs.promises.writeFile(filepath, JSON.stringify(requestData, null, 2));
  console.log(`Request logged to: ${filename}`);

  return { requestData, isTokenValid };
}

async function sendTelegramMessage(chatId: number, text: string) {
  try {
    const response = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: text
      })
    });

    const result = await response.json();
    if (!response.ok) {
      console.error('Failed to send Telegram message:', result);
      return false;
    }

    console.log('✅ Message sent to Telegram successfully');
    return true;
  } catch (error) {
    console.error('Error sending Telegram message:', error);
    return false;
  }
}

function parseTelegramMessage(body: any) {
  if (!body.message || !body.message.text) {
    return null;
  }

  const text = body.message.text.trim();
  const userId = body.message.from.id.toString();

  // Split command and args
  const parts = text.split(/\s+/);
  const command = parts[0];
  const args = parts.slice(1);

  return {
    userId,
    command,
    args,
    originalMessage: text
  };
}

async function orchestrator(requestData: any) {
  console.log('Orchestrating request...');

  try {
    const parsedMessage = parseTelegramMessage(requestData.body);

    if (!parsedMessage) {
      return {
        status: 'ignored',
        message: 'No message text found or not a text message'
      };
    }

    console.log(`Processing command: ${parsedMessage.command} for user ${parsedMessage.userId}`);

    const result = await processCommand(parsedMessage);

    return {
      status: 'processed',
      command: parsedMessage.command,
      userId: parsedMessage.userId,
      success: result.success,
      message: result.message,
      data: result.data
    };

  } catch (error: any) {
    console.error('Error in orchestrator:', error);
    return {
      status: 'error',
      message: 'Internal error processing command',
      error: error.message
    };
  }
}

async function handleWebhookMessage(requestData: any) {
  console.log('Handling webhook message...');
  return await orchestrator(requestData);
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { requestData, isTokenValid } = await preProcessRequest(req);

    if (!isTokenValid) {
      console.log('Invalid or missing secret token');
      return res.status(401).json({ error: 'Unauthorized' });
    }

    console.log('Secret token valid - processing message');
    const result = await handleWebhookMessage(requestData);

    // Send response back to Telegram if we have a chat ID and message
    if (requestData.body && requestData.body.message && requestData.body.message.chat) {
      const chatId = requestData.body.message.chat.id;
      const responseMessage = result.message || 'Command processed';

      await sendTelegramMessage(chatId, responseMessage);
    }

    res.status(200).json({ status: 'received', result });
  } catch (error: any) {
    console.error('Error processing webhook:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}